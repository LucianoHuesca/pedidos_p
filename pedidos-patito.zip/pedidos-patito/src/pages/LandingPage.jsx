function LandingPage() {
    return (
        <div style={{ textAlign: 'center' }}>
            <h1>Bienvenido al Sistema de Pedidos mas Patito</h1>
            <p>Que nuestro nombre no te engañe, best cuacklity ever.</p>
        </div>
    );
}

export default LandingPage;
