package com.mx.Gradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaTecnicaGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
