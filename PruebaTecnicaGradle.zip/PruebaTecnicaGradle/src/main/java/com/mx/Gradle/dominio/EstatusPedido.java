package com.mx.Gradle.dominio;

public enum EstatusPedido {
    PENDIENTE,
    ENTREGADO,
    CANCELADO
}
