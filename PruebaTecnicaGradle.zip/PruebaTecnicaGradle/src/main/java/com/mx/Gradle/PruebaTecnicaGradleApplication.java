package com.mx.Gradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaTecnicaGradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaTecnicaGradleApplication.class, args);
	}

}
